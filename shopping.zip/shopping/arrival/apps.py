from django.apps import AppConfig


class ArrivalConfig(AppConfig):
    name = 'arrival'
