from django.shortcuts import render, get_object_or_404
from .models import Arrival
# Create your views here.


def arrival_detail(request, pk):
    arrival = Arrival.objects.filter(pk=pk)
    return render(request, 'webpage/arrival_detail.html', {'arrival': arrival})
