from django.apps import AppConfig


class SaleoffConfig(AppConfig):
    name = 'saleoff'
