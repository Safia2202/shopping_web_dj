from django.shortcuts import render, get_object_or_404
from .models import Saleoff
# Create your views here.


def saleoff_detail(request, pk):
    saleoff = Saleoff.objects.filter(pk=pk)
    return render(request, 'webpage/saleoff_detail.html', {'saleoff': saleoff})

# Create your views here.
