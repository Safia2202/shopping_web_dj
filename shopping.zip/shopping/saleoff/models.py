from django.db import models
from django.contrib.auth.models import User


class Saleoff(models.Model):

    name = models.CharField(max_length=300)
    body = models.CharField(max_length=1000)
    date_added = models.DateTimeField(auto_now_add=True, null=True)
    image = models.ImageField(null=True, blank=True)

    def __str__(self):
        return str(self.name)

    @property
    def imageUrl(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url

# Create your models here.


