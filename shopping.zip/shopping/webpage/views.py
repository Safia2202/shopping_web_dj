from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse
from django.contrib.auth.forms import UserCreationForm
from .models import *
from django.http import JsonResponse
import datetime
import json
from django.db.models import Q
from .filter import ProductFilter
from arrival.models import *
from saleoff.models import *
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from .forms import CreateUserForm, OrderForm, CustomerForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .decorators import *
from django.contrib.auth.models import Group
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
# Create your views here.


def home(request):
    orders = Order.objects.all()
    customers = Customer.objects.all()
    total_customers = customers.count()
    total_orders = orders.count()
    delivered = orders.filter(status='Delivered').count()
    pending = orders.filter(status='Pending').count()
    site = Webpage.objects.get(pk=2)
    arrival = Arrival.objects.all()
    saleoff = Saleoff.objects.all()
    trending = Trending.objects.all()

    return render(request, 'webpage/home.html', {'orders': orders, 'customers': customer, 'total_customers': total_customers, 'total_orders': total_orders, 'delivered': delivered, 'pending': pending, 'site': site, 'arrival': arrival, 'saleoff': saleoff, 'trending': trending})


def trending_detail(request, pk):
    trending = Trending.objects.filter(id=pk)
    return render(request, 'webpage/trending_detail.html', {'trending': trending})


def customer(request, pk_test):
    customer = Customer.objects.get(id=pk_test)
    orders = customer.order_set.all()
    order_count = orders.count()
    # myFilter = Order
    return render(request, 'webpage/customer.html', {'customer': customer})


def createOrder(request):
    form = OrderForm()
    if request.method == 'POST':
        # print('printing POST:', request.POST)
        form = OrderForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')
    context = {}
    return render(request, 'webpage/order_form.html', context)

# def updateOrder(request, pk):

#	order = Order.objects.get(id=pk)
#	form = OrderForm(instance=order)

#	if request.method == 'POST':
#		form = OrderForm(request.POST, instance=order)
#		if form.is_valid():
#			form.save()
#			return redirect('/')

#	context = {'form':form}
#	return render(request, 'accounts/order_form.html', context)


@login_required(login_url='login')
def cart(request):

    if request.user.is_authenticated:
        customer = request.user.customer
        order, created = Order.objects.get_or_create(
            customer=customer, complete=False)
        items = order.orderitem_set.all()
        cartItems = order.get_item_total
    else:
        items = []
        order = {'get_cart_total': 0, 'get_item_total': 0, 'shipping': False}
        cartItems = order['get_item_total']

    context = {'items': items, 'order': order, 'cartItems': cartItems}

    return render(request, 'webpage/cart.html', context)


def deleteOrder(request, pk):
    order = Order.objects.get(id=pk)
    if request.method == 'POST':
        order.delete()

    context = {'item': order}
    return render(request, 'webpage/delete.html', context)


@login_required(login_url='login')
def checkout(request):

    if request.user.is_authenticated:
        customer = request.user.customer
        order, created = Order.objects.get_or_create(
            customer=customer, complete=False)
        items = order.orderitem_set.all()
        cartItems = order.get_item_total
    else:
        return redirect('login')
        # items = []
        # order = {'get_cart_total': 0, 'get_item_total': 0, 'shipping': False}
        # cartItems = order['get_item_total']

    context = {'items': items, 'order': order, 'cartItems': cartItems}
    return render(request, 'webpage/checkout.html', context)


def store(request):

    if request.user.is_authenticated:
        customer = request.user.customer
        order, created = Order.objects.get_or_create(
            customer=customer, complete=False)
        items = order.orderitem_set.all()
        cartItems = order.get_item_total

    else:
        items = []
        order = {'get_cart_total': 0, 'get_item_total': 0, 'shipping': False}
        cartItems = order['get_item_total']

# myFilter = ProductFilter(request.GET,#queryset=Products)
# products=myFilter.qs
    products = Product.objects.all()
    page = request.GET.get('page')
    paginator = Paginator(products, 3)
    try:
        products = paginator.page(page)
    except PageNotAnInteger:
        products = paginator.page(1)
    except EmptyPage:
        products = paginator.page(paginator.num_pages)

    #myFilter = ProductFilter(request.GET, queryset=products)
    #products = myFilter.qs
    context = {'products': products, 'cartItems': cartItems}
    # 'myFilter': myFilter
    return render(request, 'webpage/store.html', context)


def product_detail(request, pk):
    product = Product.objects.filter(id=pk)
    return render(request, 'webpage/product_detail.html', {'product': product})


# def registerPage(request):
   #  context = {}
   #  return render(request, 'webpage/register.html', context)

# @unauthenticated_user
def register(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        form = CreateUserForm()
        if request.method == 'POST':
            form = CreateUserForm(request.POST)
            if form.is_valid():
                user = form.save()
                username = form.cleaned_data.get('username')

                # group = Group.objects.get(name='customer')
                # user.groups.add(group)
                messages.success(
                    request, 'Account was created for ' + username)
                return redirect('login')

        # if form.is_valid():
        #        # saving the registered user
        #       user = form.sav
        #      Customer.objects.create(
        #        user=user,
        #         name=user.username,
        #       email=user.email
        #  )
        # username = form.cleaned_data.get('username')
        # messages.success(
        #   request, f'Your Account has been created! You can now log in')
        #  return redirect('login')
        # else:
        #   form = UserCreationForm()  # creates an empty form
        # return render(request, 'webpage/register.html', {'form': form})
    context = {'form': form}
    return render(request, 'webpage/register.html', context)


def loginPage(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                return redirect('home')

            else:
                messages.infor(request, 'Username OR Password is incorrect')

    context = {}
    return render(request, 'webpage/login.html', context)


def logoutUser(request):
    logout(request)
    return redirect('login')


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def updateItem(request):
    data = json.loads(request.body)
    productId = data['productId']
    action = data['action']
    print('Action:', action)
    print('Product:', productId)

    customer = request.user.customer
    product = Product.objects.get(id=productId)
    order, created = Order.objects.get_or_create(
        customer=customer, complete=False)

    orderItem, created = OrderItem.objects.get_or_create(
        order=order, product=product)

    if action == 'add':
        orderItem.quantity = (orderItem.quantity + 1)
    elif action == 'remove':
        orderItem.quantity = (orderItem.quantity - 1)

    orderItem.save()

    if orderItem.quantity <= 0:
        orderItem.delete()

    return JsonResponse('Item was added', safe=False)


@login_required(login_url='login')
def processOrder(request):
    transaction_id = datetime.datetime.now().timestamp()
    date = json.loads(request.body)
    if request.user.is_authenticated:
        customer = request.user.customer
        orderItem, created = OrderItem.objects.get_or_create(
            customer=customer, complete=False)
        total = float(data['form']['total'])
        order.transaction_id = transaction_id

        if total == order.get_cart_total:
            order.complete = True
        order.save()

        if order.shipping == True:
            ShippingAddress.objects.create(
                customer=customer,
                order=order,
                address=data['shipping']['address'],
                city=data['shipping']['city'],
                state=data['shipping']['state'],
                zipcode=data['shipping']['zipcode'],

            )

    return JsonResponse('Payment complete', safe=False)


# def searchbar(request):
#	if request.method =='GET':
# search =request.GET.get('search')
#		post= Product.objects.all().filter(name = search)
#
#		return render(request,'webpage/searchbar.html', {'post':post})


# def login(request):
  #  if request.method == 'POST':

    #  username = request.POST['username']
    #   password = request.POST['password']

    #    if username != "" and password != "":
   #         user = authenticate(request, username=username, #password=password)
 #           if user != None:
    #      login(request, user)
    #       return redirect('webpage/login.html')

    #    else:
    #         return render(request, 'webpage/register.html', {'form': form})


# def searchbar(request):
 #   if request.method == 'POST':
  #      txt = request.POST.get('')
   #     print(txt)
    #site = Webpage.objects.get(pk=2)
  #  arrival = Arrival.objects.all()
   # saleoff = Saleoff.objects.all()
    #products = Product.objects.all()


@login_required(login_url='login')
def accountPage(request):
    orders = request.user.customer.order_set.all()
    # total_orders = orders.count()
    # delivered = orders.filter(status='Delivered').count()
    pending = orders.filter(status='Pending').count()
    customer = request.user.customer
    form = CustomerForm(instance=customer)
    # print('ORDERS:', orders)

    if request.method == 'POST':
        form = CustomerForm(request.POST, request.FILES, instance=customer)
        if form.is_valid():
            form.save()

    context = {'form': form}
    return render(request, 'webpage/accountpage.html', context)
# 'orders': orders, 'total_orders',total_orders,'delivered': delivered, 'pending': pending


# def paginatorCreate(request):

   # product_list = Product.objects.all().order_by('-id')
    #paginator = Paginator(product_list, 5)

    # try:
  #      page = int(request.GET.get('page', '1')
  #  except:
   #     page=1

   # return render(request)


def searchbar(request):
    products = Product.objects.filter(active=True)
    myFilter = ProductFilter(request.GET, queryset=products)
    products = myFilter.qs

    page = request.GET.get('page')
    paginator = Paginator(products, 3)
    try:
        products = paginator.page(page)
    except PageNotAnInteger:
        products = paginator.page(1)
    except EmptyPage:
        products = paginator.page(paginator.num_pages)
    context = {'products': products, "myFilter": myFilter}
    return render(request, 'webpage/searchbar.html', context)
